#DOTCMS_CORE

- Fixes: Prevent Directory Traversal in bundle uploader
- Github Issue: https://github.com/dotCMS/core/issues/10974
- Security Report: http://dotcms.com/security/SI-41